// HAMBURGER MENU
function toggleHamburger() {
	var hamburgerMenu = document.getElementById('hamburger-menu');
	hamburgerMenu.classList.toggle('show-hamburger-menu');
	hamburgerButton.classList.toggle('close-hamburger-menu');
}
var hamburgerButton = document.getElementById('hamburger-menu-button');

hamburgerButton.addEventListener('click', function() {
	toggleHamburger();
});

hamburgerButton.addEventListener('keyup', function(event) {
  event.preventDefault();
  if (event.keyCode === 13) {
	toggleHamburger();
  }
});

function systemMessage(type, text) {
	var systemMessageBox = document.getElementById('system-message-box');
	systemMessageBox.style.display = 'block';
	systemMessageBox.className += ' ' + type;
	systemMessageBox.innerHTML = text;
	hamburgerButton.classList.toggle('close-hamburger-menu');
	window.scrollTo(0, 0);
}


// CALL THE DEFAULT PRINT DIALOG
function printPage() {
	setTimeout(function() {
		window.print();
	}, 100);
}

// BIND PRINT FUNCTION TO EVERYTHING THAT HAS CLASS print-page
function getAllPrintButtons() {
	var printButton =  document.getElementsByClassName('print-page');
	for (var i = 0; i < printButton.length; i++) {
		printButton[i].addEventListener('click', printPage);
	}
}
getAllPrintButtons();


// DEVELOPER NOTES
function getDevNotes() {
	var hint =  document.getElementsByClassName('dev-note');
	for (var i = 0; i < hint.length; i++) {
		hint[i].addEventListener('click', showNote);
	}
}
getDevNotes();

function showNote() {
	var thisValue = this.title;
	alert(thisValue);
}