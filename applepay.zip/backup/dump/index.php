<?php
if(isset($_POST['submit_button'])) {
	$sent_data = $_POST['data'];
	$file_name = date('Y-m-d-H-i-s').'.txt'; 
	file_put_contents($file_name, $sent_data, FILE_APPEND | LOCK_EX);
	echo date("Y-m-d H:i:s").': Saved.';
}
?>

<form name="bizLoginForm" method="post" action"<?php echo $_SERVER['PHP_SELF']?>" >
	<textarea name="data" style="width: 80%; height: 50%;"></textarea>
	<br>
	<input type="Submit" name="submit_button" value="Submit" />
</form>