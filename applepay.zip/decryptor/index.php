<?php

$decryptedObject = array(
    'ProcStatus' => '0',
    'TokenData' => array(
        'applicationPrimaryAccountNumber' => '4777779999999990',
        'applicationExpirationDate' => '170430',
        'currencyCode' => '840',
        'transactionAmount' => '1000',
		'transactionAmount' => '1000',
		'deviceManufacturerIdentifier' => '040010030273',
        'paymentDataType' => '3DSecure',
        'paymentData' => array(
            'onlinePaymentCryptogram' => 'Bwa',
            'eciIndicator' => -1
            )
        )
);

$json = json_encode($decryptedObject);

echo $json;

?>