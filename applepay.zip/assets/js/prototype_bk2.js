function getAmount() {
    var amountDue = null;

    if (document.getElementById('pay-full-balance-due').checked == true) {
        amountDue = fullBalance = 0.99;
    } else if (document.getElementById('pay-partial-balance-due').checked == true) {
        amountDue = document.getElementById('input-pay-partial-balance').value;
    } else {
		amountDue = null;
    }
    return amountDue;
}

const applePayMethod = {
    supportedMethods: "https://apple.com/apple-pay",
    data: {
        version: 3,
        merchantIdentifier: "merchant.com.uireference.pcx",
        merchantCapabilities: ["supports3DS", "supportsCredit", "supportsDebit"],
        supportedNetworks: ["amex", "discover", "masterCard", "visa"],
        countryCode: "US",
        currencyCode: "USD"
    },
};


const paymentOptions = {
    requestPayerName: false,
    requestPayerEmail: false,
    requestPayerPhone: false
};

async function applePayButtonClicked()
{

    const paymentDetails = {
        id: "transaction1",
        total: {
            label: "AppleXion",
            type: "final",
            amount: { value: getAmount(), currency: "USD" },
        }
    };
    
    // Consider falling back to Apple Pay JS if Payment Request is not available.
    if (!window.PaymentRequest)
        return;

    try {
        const request = new PaymentRequest([applePayMethod], paymentDetails, paymentOptions);
        request.onmerchantvalidation = function (event) {
            // Have your server fetch a payment session from event.validationURL.
            //alert(event.validationURL);
            //alert (JSON.stringify(event));
            const sessionPromise = fetchPaymentSession(event.validationURL);
            event.complete(sessionPromise);
        };
        //alert('validated?');
        const response = await request.show();
        response.complete("success");
        //const status = processResponse(response);
        //response.complete(status);
    } catch (e) {
        alert(e);
    }
}

// HAMBURGER MENU
function toggleHamburger() {
	var hamburgerMenu = document.getElementById('hamburger-menu');
	hamburgerMenu.classList.toggle('show-hamburger-menu');
	hamburgerButton.classList.toggle('close-hamburger-menu');
}
var hamburgerButton = document.getElementById('hamburger-menu-button');

hamburgerButton.addEventListener('click', function() {
	toggleHamburger();
});

hamburgerButton.addEventListener('keyup', function(event) {
  event.preventDefault();
  if (event.keyCode === 13) {
	toggleHamburger();
  }
});

function systemMessage(type, text) {
	var systemMessageBox = document.getElementById('system-message-box');
	systemMessageBox.style.display = 'block';
	systemMessageBox.className += ' ' + type;
	systemMessageBox.innerHTML = text;
	hamburgerButton.classList.toggle('close-hamburger-menu');
	window.scrollTo(0, 0);
}


// CALL THE DEFAULT PRINT DIALOG
function printPage() {
	setTimeout(function() {
		window.print();
	}, 100);
}

// BIND PRINT FUNCTION TO EVERYTHING THAT HAS CLASS print-page
function getAllPrintButtons() {
	var printButton =  document.getElementsByClassName('print-page');
	for (var i = 0; i < printButton.length; i++) {
		printButton[i].addEventListener('click', printPage);
	}
}
getAllPrintButtons();


// DEVELOPER NOTES
function getDevNotes() {
	var hint =  document.getElementsByClassName('dev-note');
	for (var i = 0; i < hint.length; i++) {
		hint[i].addEventListener('click', showNote);
	}
}
getDevNotes();

function showNote() {
	var thisValue = this.title;
	alert(thisValue);
}
