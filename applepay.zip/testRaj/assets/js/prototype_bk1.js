const applePayMethod = {
    supportedMethods: "https://apple.com/apple-pay",
    data: {
        version: 3,
        merchantIdentifier: "merchant.com.example",
        merchantCapabilities: ["supports3DS", "supportsCredit", "supportsDebit"],
        supportedNetworks: ["amex", "discover", "masterCard", "visa"],
        countryCode: "US",
    },
};

const paymentDetails = {
    total: {
        label: "AppleXion",
        amount: { value: "0.01", currency: "USD" },
    }
};

const paymentOptions = {
    requestPayerName: true,
    requestPayerEmail: true,
    requestPayerPhone: true
};

async function applePayButtonClicked()
{
    // Consider falling back to Apple Pay JS if Payment Request is not available.
    if (!window.PaymentRequest)
        return;

    try {
        const request = new PaymentRequest([applePayMethod], paymentDetails, paymentOptions);

        request.onmerchantvalidation = function (event) {
            // Have your server fetch a payment session from event.validationURL.
            const sessionPromise = fetchPaymentSession(event.validationURL);
            event.complete(sessionPromise);
        };

        request.onshippingoptionchange = function (event) {
            // Compute new payment details based on the selected shipping option.
            const detailsUpdatePromise = computeDetails();
            event.updateWith(detailsUpdatePromise);
        };

        request.onshippingaddresschange = function (event) {
            // Compute new payment details based on the selected shipping address.
            const detailsUpdatePromise = computeDetails();
            event.updateWith(detailsUpdatePromise);
        };

        const response = await request.show();
        const status = processResponse(response);
        response.complete(status);
    } catch (e) {
        // Handle errors
    }
}

// HAMBURGER MENU
function toggleHamburger() {
	var hamburgerMenu = document.getElementById('hamburger-menu');
	hamburgerMenu.classList.toggle('show-hamburger-menu');
	hamburgerButton.classList.toggle('close-hamburger-menu');
}
var hamburgerButton = document.getElementById('hamburger-menu-button');

hamburgerButton.addEventListener('click', function() {
	toggleHamburger();
});

hamburgerButton.addEventListener('keyup', function(event) {
  event.preventDefault();
  if (event.keyCode === 13) {
	toggleHamburger();
  }
});

function systemMessage(type, text) {
	var systemMessageBox = document.getElementById('system-message-box');
	systemMessageBox.style.display = 'block';
	systemMessageBox.className += ' ' + type;
	systemMessageBox.innerHTML = text;
	hamburgerButton.classList.toggle('close-hamburger-menu');
	window.scrollTo(0, 0);
}


// CALL THE DEFAULT PRINT DIALOG
function printPage() {
	setTimeout(function() {
		window.print();
	}, 100);
}

// BIND PRINT FUNCTION TO EVERYTHING THAT HAS CLASS print-page
function getAllPrintButtons() {
	var printButton =  document.getElementsByClassName('print-page');
	for (var i = 0; i < printButton.length; i++) {
		printButton[i].addEventListener('click', printPage);
	}
}
getAllPrintButtons();


// DEVELOPER NOTES
function getDevNotes() {
	var hint =  document.getElementsByClassName('dev-note');
	for (var i = 0; i < hint.length; i++) {
		hint[i].addEventListener('click', showNote);
	}
}
getDevNotes();

function showNote() {
	var thisValue = this.title;
	alert(thisValue);
}
